# wordpress-indesign-tagged-text-export
A Wordpress Plugin to export posts as InDesign Tagged text
